// ----------------------------------------------------------------------

export const imageClasses = {
  root: 'mnl__image__root',
  wrapper: 'mnl__image__wrapper',
  overlay: 'mnl__image__overlay',
};
