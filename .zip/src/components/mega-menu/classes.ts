// ----------------------------------------------------------------------

export const megaMenuClasses = {
  horizontal: {
    root: 'mega__menu__desktop__horizontal',
  },
  vertical: {
    root: 'mega__menu__desktop__vertical',
  },
  mobile: {
    root: 'mega__menu__desktop__mobile',
  },
};
