// ----------------------------------------------------------------------

export const chartClasses = { root: 'mnl__chart__root' };
