// ----------------------------------------------------------------------

export const lightboxClasses = { root: 'mnl__lightbox__root' };
