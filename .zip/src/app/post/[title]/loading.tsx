import { PostDetailsSkeleton } from 'src/sections/blog/post-skeleton';

// ----------------------------------------------------------------------

export default function Loading() {
  return <PostDetailsSkeleton />;
}
